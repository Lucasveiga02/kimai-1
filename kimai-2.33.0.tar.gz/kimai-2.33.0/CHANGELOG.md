# Changelog

See [GitHub release page](https://github.com/kimai/kimai/releases). 
