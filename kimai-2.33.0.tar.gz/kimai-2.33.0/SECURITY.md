# Security Policy

As announced in the [README](README.md) security fixes will only be added to the `main` branch. 

| Version              | Supported          |
|----------------------|--------------------|
| main branch          | :white_check_mark: |
| older releases       | :x:                |

You find all information in our [Bughunter documentation](https://www.kimai.org/documentation/bughunter.html).   
